-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.8.4-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for fl1ght_game
DROP DATABASE IF EXISTS `fl1ght_game`;
CREATE DATABASE IF NOT EXISTS `fl1ght_game` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `fl1ght_game`;

-- Dumping structure for table fl1ght_game.airport
DROP TABLE IF EXISTS `airport`;
CREATE TABLE IF NOT EXISTS `airport` (
  `id` int(11) NOT NULL,
  `ident` varchar(40) NOT NULL,
  `name` varchar(40) DEFAULT NULL,
  `latitude_deg` double DEFAULT NULL,
  `longitude_deg` double DEFAULT NULL,
  `iso_country` varchar(40) DEFAULT NULL,
  `air_pollution` int(1) DEFAULT NULL,
  PRIMARY KEY (`ident`),
  KEY `iso_country` (`iso_country`),
  CONSTRAINT `airport_ibfk_1` FOREIGN KEY (`iso_country`) REFERENCES `country` (`iso_country`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table fl1ght_game.airport: ~100 rows (approximately)
/*!40000 ALTER TABLE `airport` DISABLE KEYS */;
INSERT INTO `airport` (`id`, `ident`, `name`, `latitude_deg`, `longitude_deg`, `iso_country`, `air_pollution`) VALUES
	(123, 'BIKF', 'Keflavik International Airport', 63.985001, -22.6056, 'IS', 2),
	(2155, 'EBBR', 'Brussels Airport', 50.901401519800004, 4.48443984985, 'BE', 1),
	(301881, 'EDDB', 'Berlin Brandenburg Airport', 52.351389, 13.493889, 'DE', 1),
	(2212, 'EDDF', 'Frankfurt am Main Airport', 50.036249, 8.559294, 'DE', 1),
	(2214, 'EDDH', 'Hamburg Helmut Schmidt Airport', 53.630402, 9.98823, 'DE', 1),
	(2216, 'EDDK', 'Cologne Bonn Airport', 50.8658981323, 7.1427397728, 'DE', 1),
	(2217, 'EDDL', 'Düsseldorf Airport', 51.289501, 6.76678, 'DE', 1),
	(2218, 'EDDM', 'Munich Airport', 48.353802, 11.7861, 'DE', 2),
	(2219, 'EDDN', 'Nuremberg Airport', 49.498699, 11.078056, 'DE', 1),
	(2220, 'EDDP', 'Leipzig/Halle Airport', 51.423889, 12.236389, 'DE', 1),
	(2222, 'EDDS', 'Stuttgart Airport', 48.689899444599995, 9.22196006775, 'DE', 1),
	(2224, 'EDDV', 'Hannover Airport', 52.461101532, 9.685079574580001, 'DE', 1),
	(2301, 'EETN', 'Lennart Meri Tallinn Airport', 59.41329956049999, 24.832799911499997, 'EE', 1),
	(2307, 'EFHK', 'Helsinki Vantaa Airport', 60.3172, 24.963301, 'FI', 2),
	(2385, 'EGAA', 'Belfast International Airport', 54.6575012207, -6.2158298492399995, 'GB', 2),
	(2389, 'EGBB', 'Birmingham International Airport', 52.453899383499994, -1.74802994728, 'GB', 2),
	(2398, 'EGCC', 'Manchester Airport', 53.349375, -2.279521, 'GB', 2),
	(2419, 'EGGW', 'London Luton Airport', 51.874698638916016, -0.36833301186561584, 'GB', 2),
	(2429, 'EGKK', 'London Gatwick Airport', 51.148102, -0.190278, 'GB', 2),
	(2434, 'EGLL', 'London Heathrow Airport', 51.4706, -0.461941, 'GB', 2),
	(2461, 'EGPF', 'Glasgow International Airport', 55.871899, -4.43306, 'GB', 2),
	(2462, 'EGPH', 'Edinburgh Airport', 55.950145, -3.372288, 'GB', 2),
	(2476, 'EGSS', 'London Stansted Airport', 51.8849983215, 0.234999999404, 'GB', 2),
	(2513, 'EHAM', 'Amsterdam Airport Schiphol', 52.308601, 4.76389, 'NL', 2),
	(2518, 'EHEH', 'Eindhoven Airport', 51.4500999451, 5.37452983856, 'NL', 1),
	(2533, 'EIDW', 'Dublin Airport', 53.421299, -6.27007, 'IE', 2),
	(2537, 'EINN', 'Shannon Airport', 52.702, -8.92482, 'IE', 2),
	(2541, 'EKBI', 'Billund Airport', 55.7402992249, 9.15178012848, 'DK', 1),
	(2542, 'EKCH', 'Copenhagen Kastrup Airport', 55.617900848389, 12.656000137329, 'DK', 1),
	(2563, 'ELLX', 'Luxembourg-Findel International Airport', 49.6233333, 6.2044444, 'LU', 1),
	(2570, 'ENBR', 'Bergen Airport, Flesland', 60.2934, 5.21814, 'NO', 2),
	(2578, 'ENGM', 'Oslo Airport, Gardermoen', 60.193901, 11.1004, 'NO', 1),
	(2599, 'ENTC', 'Tromsø Airport, Langnes', 69.683296, 18.9189, 'NO', 1),
	(2601, 'ENVA', 'Trondheim Airport, Værnes', 63.457802, 10.924, 'NO', 1),
	(2602, 'ENZV', 'Stavanger Airport, Sola', 58.876701, 5.63778, 'NO', 2),
	(2608, 'EPGD', 'Gdansk Lech Walesa Airport', 54.377601623535156, 18.46619987487793, 'PL', 1),
	(2609, 'EPKK', 'Kraków John Paul II International Airpor', 50.077702, 19.7848, 'PL', 1),
	(2637, 'EPWA', 'Warsaw Chopin Airport', 52.1656990051, 20.967100143399996, 'PL', 1),
	(2648, 'ESGG', 'Gothenburg-Landvetter Airport', 57.662799835205, 12.279800415039, 'SE', 1),
	(2701, 'ESSA', 'Stockholm-Arlanda Airport', 59.651901245117, 17.918600082397, 'SE', 1),
	(2758, 'EVRA', 'Riga International Airport', 56.92359924316406, 23.971099853515625, 'LV', 1),
	(2766, 'EYVI', 'Vilnius International Airport', 54.634102, 25.285801, 'LT', 1),
	(3077, 'GCFV', 'Fuerteventura Airport', 28.4527, -13.8638, 'ES', 5),
	(3081, 'GCLP', 'Gran Canaria Airport', 27.9319, -15.3866, 'ES', 5),
	(3082, 'GCRR', 'César Manrique-Lanzarote Airport', 28.945499, -13.6052, 'ES', 5),
	(3083, 'GCTS', 'Tenerife Sur Airport', 28.0445, -16.5725, 'ES', 2),
	(3972, 'LATI', 'Tirana International Airport Mother Tere', 41.4146995544, 19.7206001282, 'AL', 2),
	(3974, 'LBBG', 'Burgas Airport', 42.56959915161133, 27.515199661254883, 'BG', 1),
	(3977, 'LBSF', 'Sofia Airport', 42.696693420410156, 23.411436080932617, 'BG', 2),
	(3979, 'LBWN', 'Varna Airport', 43.232101, 27.8251, 'BG', 1),
	(3993, 'LDZA', 'Zagreb Airport', 45.7429008484, 16.0687999725, 'HR', 1),
	(3997, 'LEAL', 'Alicante-Elche Miguel Hernández Airport', 38.2822, -0.558156, 'ES', 2),
	(4004, 'LEBL', 'Josep Tarradellas Barcelona-El Prat Airp', 41.2971, 2.07846, 'ES', 2),
	(4013, 'LEIB', 'Ibiza Airport', 38.872898, 1.37312, 'ES', 2),
	(4019, 'LEMD', 'Adolfo Suárez Madrid–Barajas Airport', 40.471926, -3.56264, 'ES', 2),
	(4020, 'LEMG', 'Málaga-Costa del Sol Airport', 36.6749, -4.49911, 'ES', 2),
	(4035, 'LEPA', 'Palma de Mallorca Airport', 39.551701, 2.73881, 'ES', 2),
	(4038, 'LEST', 'Santiago-Rosalía de Castro Airport', 42.896301, -8.41514, 'ES', 1),
	(4060, 'LFBD', 'Bordeaux-Mérignac Airport', 44.8283, -0.715556, 'FR', 2),
	(4070, 'LFBO', 'Toulouse-Blagnac Airport', 43.629101, 1.36382, 'FR', 1),
	(4137, 'LFLL', 'Lyon Saint-Exupéry Airport', 45.725556, 5.081111, 'FR', 2),
	(4155, 'LFML', 'Marseille Provence Airport', 43.439271922, 5.22142410278, 'FR', 2),
	(4156, 'LFMN', 'Nice-Côte d\'Azur Airport', 43.6584014893, 7.215869903560001, 'FR', 2),
	(4185, 'LFPG', 'Charles de Gaulle International Airport', 49.012798, 2.55, 'FR', 1),
	(4189, 'LFPO', 'Paris-Orly Airport', 48.7233333, 2.3794444, 'FR', 1),
	(4226, 'LFSB', 'EuroAirport Basel-Mulhouse-Freiburg Airp', 47.59, 7.529167, 'FR', 2),
	(4251, 'LGAV', 'Athens Eleftherios Venizelos Internation', 37.936401, 23.9445, 'GR', 2),
	(4258, 'LGIR', 'Heraklion International Nikos Kazantzaki', 35.3396987915, 25.180299758900002, 'GR', 2),
	(4293, 'LGTS', 'Thessaloniki Macedonia International Air', 40.51969909667969, 22.97089958190918, 'GR', 2),
	(4296, 'LHBP', 'Budapest Liszt Ferenc International Airp', 47.42976, 19.261093, 'HU', 2),
	(4318, 'LICC', 'Catania-Fontanarossa Airport', 37.466801, 15.0664, 'IT', 2),
	(4321, 'LICJ', 'Falcone–Borsellino Airport', 38.175999, 13.091, 'IT', 2),
	(4332, 'LIEE', 'Cagliari Elmas Airport', 39.251499, 9.05428, 'IT', 2),
	(4340, 'LIMC', 'Malpensa International Airport', 45.6306, 8.72811, 'IT', 1),
	(4341, 'LIME', 'Milan Bergamo Airport', 45.673901, 9.70417, 'IT', 1),
	(4342, 'LIMF', 'Turin Airport', 45.200802, 7.64963, 'IT', 2),
	(4354, 'LIPE', 'Bologna Guglielmo Marconi Airport', 44.5354, 11.2887, 'IT', 3),
	(4366, 'LIPX', 'Verona Villafranca Airport', 45.395699, 10.8885, 'IT', 3),
	(4368, 'LIPZ', 'Venice Marco Polo Airport', 45.505299, 12.3519, 'IT', 3),
	(4372, 'LIRF', 'Rome–Fiumicino Leonardo da Vinci Interna', 41.804532, 12.251998, 'IT', 2),
	(4378, 'LIRN', 'Naples International Airport', 40.886002, 14.2908, 'IT', 3),
	(4379, 'LIRP', 'Pisa International Airport', 43.683899, 10.3927, 'IT', 1),
	(4386, 'LJLJ', 'Ljubljana Jože Pucnik Airport', 46.223701, 14.4576, 'SI', 1),
	(4408, 'LKPR', 'Václav Havel Airport Prague', 50.1008, 14.26, 'CZ', 1),
	(4427, 'LMML', 'Malta International Airport', 35.857498, 14.4775, 'MT', 2),
	(4434, 'LOWW', 'Vienna International Airport', 48.110298, 16.5697, 'AT', 3),
	(4448, 'LPFR', 'Faro Airport', 37.0144004822, -7.96590995789, 'PT', 3),
	(4456, 'LPPD', 'João Paulo II Airport', 37.7411994934, -25.6979007721, 'PT', 2),
	(4459, 'LPPR', 'Francisco de Sá Carneiro Airport', 41.2481002808, -8.68138980865, 'PT', 1),
	(4461, 'LPPT', 'Humberto Delgado Airport (Lisbon Portela', 38.7813, -9.13592, 'PT', 2),
	(4482, 'LROP', 'Henri Coanda International Airport', 44.5711111, 26.085, 'RO', 3),
	(4490, 'LSGG', 'Geneva Cointrin International Airport', 46.23809814453125, 6.108950138092041, 'CH', 2),
	(4505, 'LSZH', 'Zürich Airport', 47.458056, 8.548056, 'CH', 2),
	(4573, 'LWSK', 'Skopje International Airport', 41.961601, 21.621401, 'MK', 3),
	(4610, 'LYBE', 'Belgrade Nikola Tesla Airport', 44.8184013367, 20.3090991974, 'RS', 3),
	(4613, 'LYPG', 'Podgorica Airport / Podgorica Golubovci ', 42.359402, 19.2519, 'ME', 2),
	(4617, 'LZIB', 'M. R. Štefánik Airport', 48.17020034790039, 17.21269989013672, 'SK', 2),
	(6467, 'UKBB', 'Boryspil International Airport', 50.345001220703125, 30.894699096679688, 'UA', 1),
	(6481, 'UKLL', 'Lviv International Airport', 49.8125, 23.9561, 'UA', 1),
	(6501, 'UMMS', 'Minsk National Airport', 53.888071, 28.039964, 'BY', 1);
/*!40000 ALTER TABLE `airport` ENABLE KEYS */;

-- Dumping structure for table fl1ght_game.goal
DROP TABLE IF EXISTS `goal`;
CREATE TABLE IF NOT EXISTS `goal` (
  `id` int(11) NOT NULL,
  `name` varchar(40) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `icon` varchar(8) DEFAULT NULL,
  `target` varchar(40) DEFAULT NULL,
  `target_minvalue` decimal(8,2) DEFAULT NULL,
  `target_maxvalue` decimal(8,2) DEFAULT NULL,
  `target_text` varchar(40) DEFAULT NULL,
  `times_pooped` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table fl1ght_game.goal: ~8 rows (approximately)
/*!40000 ALTER TABLE `goal` DISABLE KEYS */;
INSERT INTO `goal` (`id`, `name`, `description`, `icon`, `target`, `target_minvalue`, `target_maxvalue`, `target_text`, `times_pooped`) VALUES
	(1, 'HOT', 'Temperature over +25C', '01d', 'TEMP', 25.00, 9999.00, NULL, NULL),
	(2, 'COLD', 'Temperature under -20C', '13d', 'TEMP', -9999.00, -20.00, NULL, NULL),
	(3, '0DEG', 'Temperature exactly 0C', '04d', 'TEMP', -0.50, 0.50, NULL, NULL),
	(4, '10DEG', 'Temperature exactly +10C', '04d', 'TEMP', 9.50, 10.50, NULL, NULL),
	(5, '20DEG', 'Temperature exactly +20C', '04d', 'TEMP', 19.50, 20.50, NULL, NULL),
	(6, 'CLEAR', 'Clear skies', '01d', 'WEATHER', NULL, NULL, 'Clear', NULL),
	(7, 'CLOUDS', 'Cloudy', '04d', 'WEATHER', NULL, NULL, 'Clouds', NULL),
	(8, 'WINDY', 'Wind blows more than 10 m/s', '04d', 'WIND', 10.00, 9999.00, NULL, NULL);
/*!40000 ALTER TABLE `goal` ENABLE KEYS */;

-- Dumping structure for table fl1ght_game.goal_reached
DROP TABLE IF EXISTS `goal_reached`;
CREATE TABLE IF NOT EXISTS `goal_reached` (
  `game_id` int(11) NOT NULL DEFAULT 0,
  `airport_name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`game_id`,`airport_name`) USING BTREE,
  KEY `goalid` (`airport_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table fl1ght_game.goal_reached: ~15 rows (approximately)
/*!40000 ALTER TABLE `goal_reached` DISABLE KEYS */;
INSERT INTO `goal_reached` (`game_id`, `airport_name`) VALUES
	(152, 'Heraklion International Nikos Kazantzaki'),
	(152, 'Munich Airport'),
	(153, 'Bordeaux-Mérignac Airport'),
	(153, 'Faro Airport'),
	(153, 'Glasgow International Airport'),
	(153, 'Gran Canaria Airport'),
	(153, 'Helsinki Vantaa Airport'),
	(153, 'Keflavik International Airport'),
	(153, 'Lennart Meri Tallinn Airport'),
	(153, 'Minsk National Airport'),
	(153, 'Oslo Airport, Gardermoen'),
	(153, 'Riga International Airport'),
	(153, 'Shannon Airport'),
	(153, 'Stockholm-Arlanda Airport'),
	(153, 'Trondheim Airport, Værnes');
/*!40000 ALTER TABLE `goal_reached` ENABLE KEYS */;

-- Dumping structure for table fl1ght_game.peli
DROP TABLE IF EXISTS `peli`;
CREATE TABLE IF NOT EXISTS `peli` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kakatut_kentat` int(11) NOT NULL DEFAULT 0,
  `lahjat_annettu` int(11) NOT NULL DEFAULT 0,
  `name` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `highscore` int(3) NOT NULL DEFAULT 0,
  `sijainti` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=latin1;

-- Dumping data for table fl1ght_game.peli: ~138 rows (approximately)
/*!40000 ALTER TABLE `peli` DISABLE KEYS */;
INSERT INTO `peli` (`id`, `kakatut_kentat`, `lahjat_annettu`, `name`, `highscore`, `sijainti`) VALUES
	(17, 89, 25, 'tv', 25, NULL),
	(18, 0, 0, 'ttt', 0, NULL),
	(19, 73, 0, 't', 0, NULL),
	(20, 73, 0, 't', 0, NULL),
	(21, 73, 0, 't', 0, NULL),
	(22, 73, 0, 't', 0, NULL),
	(23, 73, 0, 't', 0, NULL),
	(24, 73, 0, 't', 0, NULL),
	(25, 73, 0, 't', 0, NULL),
	(26, 0, 0, 'dsf', 0, 'Rovaniemi Airport'),
	(27, 0, 0, 'heo', 0, 'Rovaniemi Airport'),
	(28, 0, 0, 'ddgg', 0, 'Rovaniemi Airport'),
	(29, 0, 0, 'sff', 0, 'Rovaniemi Airport'),
	(30, 0, 0, 'heyy', 0, 'Rovaniemi Airport'),
	(31, 0, 0, 'liilliii', 0, 'Rovaniemi Airport'),
	(32, 0, 0, 'hehe', 0, 'Rovaniemi Airport'),
	(33, 0, 0, 'hehe', 0, 'Rovaniemi Airport'),
	(34, 0, 0, 'dsf', 0, 'Rovaniemi Airport'),
	(35, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(36, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(37, 0, 0, 'viiva', 0, 'Rovaniemi Airport'),
	(38, 0, 0, 'gee', 0, 'Rovaniemi Airport'),
	(39, 0, 0, 'gg', 0, 'Rovaniemi Airport'),
	(40, 0, 0, 'jooo', 0, 'Rovaniemi Airport'),
	(41, 0, 0, 'heheheh', 0, 'Rovaniemi Airport'),
	(42, 0, 0, 'mut', 0, 'Rovaniemi Airport'),
	(43, 0, 0, 'mikäsiinävittuon', 0, 'Rovaniemi Airport'),
	(44, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(45, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(46, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(47, 0, 0, 'nomikasnyt taas', 0, 'Rovaniemi Airport'),
	(48, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(49, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(50, 0, 0, 'miksiiii', 0, 'Rovaniemi Airport'),
	(51, 0, 0, 'viii', 0, 'Rovaniemi Airport'),
	(52, 0, 0, 'NOJOKO', 0, 'Rovaniemi Airport'),
	(53, 0, 0, 'kokeillaaaan', 0, 'Rovaniemi Airport'),
	(54, 0, 0, 'NOH', 0, 'Rovaniemi Airport'),
	(55, 0, 0, 'OHHHH', 0, 'Rovaniemi Airport'),
	(56, 0, 0, 'MIKAA', 0, 'Rovaniemi Airport'),
	(57, 0, 0, 'MIKA', 0, 'Rovaniemi Airport'),
	(58, 0, 0, 'NOH', 0, 'Rovaniemi Airport'),
	(59, 0, 0, 'MIKSEITAIDOTRIITA', 0, 'Rovaniemi Airport'),
	(60, 0, 0, 'NIIINPERKELE', 0, 'Rovaniemi Airport'),
	(61, 0, 0, '', 0, 'Rovaniemi Airport'),
	(62, 0, 0, '', 0, 'Rovaniemi Airport'),
	(63, 0, 0, 'MIKKKKK', 0, 'Rovaniemi Airport'),
	(64, 0, 0, 'MIKSII', 0, 'Rovaniemi Airport'),
	(65, 0, 0, 'noh', 0, 'Rovaniemi Airport'),
	(66, 0, 0, 'NOMUTTAMORJENS', 0, 'Rovaniemi Airport'),
	(67, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(68, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(69, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(70, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(71, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(72, 0, 0, 'HEIIILOPETA', 0, 'Rovaniemi Airport'),
	(73, 0, 0, 'hei', 0, 'Rovaniemi Airport'),
	(74, 0, 0, 'Tytti Vilén', 0, 'Rovaniemi Airport'),
	(75, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(76, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(77, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(78, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(79, 0, 0, 'vilen tytti', 0, 'Rovaniemi Airport'),
	(80, 0, 0, 'mikass', 0, 'Rovaniemi Airport'),
	(81, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(82, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(83, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(84, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(85, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(86, 0, 0, 'heihei', 0, 'Rovaniemi Airport'),
	(87, 0, 0, 'loool', 0, 'Rovaniemi Airport'),
	(88, 0, 0, 'joko', 0, 'Rovaniemi Airport'),
	(89, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(90, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(91, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(92, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(93, 0, 0, 'voivovoivoi', 0, '25.83083'),
	(94, 0, 0, '[object HTMLInputElement]', 0, '24.963301'),
	(95, 0, 0, '[object HTMLInputElement]', 0, '10.924'),
	(96, 0, 0, '[object HTMLInputElement]', 0, '11.1004'),
	(97, 0, 0, '[object HTMLInputElement]', 0, '17.918600082397'),
	(98, 0, 0, 'nohniih', 0, 'Rovaniemi Airport'),
	(99, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(100, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(101, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(102, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(103, 0, 0, 'mikas', 0, 'Rovaniemi Airport'),
	(104, 0, 0, 'joo', 0, 'Rovaniemi Airport'),
	(105, 0, 0, 'joo', 0, 'Rovaniemi Airport'),
	(106, 0, 0, 'nih', 0, 'Rovaniemi Airport'),
	(107, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(108, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(109, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(110, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(111, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(112, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(113, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(114, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(115, 0, 0, 'lil', 0, 'Rovaniemi Airport'),
	(116, 0, 0, 'bb', 0, 'Rovaniemi Airport'),
	(117, 0, 0, 'nope', 0, 'Rovaniemi Airport'),
	(118, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(119, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(120, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(121, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(122, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(123, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(124, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(125, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(126, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(127, 0, 0, 'moro', 0, 'Rovaniemi Airport'),
	(128, 0, 0, 'moro', 0, 'Rovaniemi Airport'),
	(129, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(130, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(131, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(132, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(133, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(134, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(135, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(136, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(137, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(138, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(139, 0, 0, 'kojojj', 0, 'Rovaniemi Airport'),
	(140, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(141, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(142, 0, 0, 'niih', 0, 'Rovaniemi Airport'),
	(143, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(144, 0, 0, '[object HTMLInputElement]', 0, 'undefined'),
	(145, 0, 0, 'vii', 0, 'Rovaniemi Airport'),
	(146, 0, 0, 'goo', 0, 'Rovaniemi Airport'),
	(147, 0, 0, 'dgd', 0, 'Rovaniemi Airport'),
	(148, 0, 0, 'jj', 0, 'Rovaniemi Airport'),
	(149, 0, 0, 'gg', 0, 'Rovaniemi Airport'),
	(150, 0, 0, 'dfgsd', 0, 'Rovaniemi Airport'),
	(151, 0, 0, 'gg', 0, 'Vilnius International Airport'),
	(152, 1, 0, 'fd', 0, 'Munich Airport'),
	(153, 0, 0, 'koo', 0, 'Lennart Meri Tallinn Airport'),
	(154, 0, 0, 'noh', 0, 'Rovaniemi Airport');
/*!40000 ALTER TABLE `peli` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
